#!/bin/bash
IP=$(ifconfig eth0 | sed -n 2p| awk '{print $2}')
TOKEN='3s_jPwebNAo2wTAksgsy'
TIMEOUT=10
PROJECT='projects'
return_code=$(/bin/curl --header "Private-Token: $TOKEN" -o /dev/null -s -w %{http_code} -m $TIMEOUT http://$IP/api/v4/"$PROJECT")

endpoint=$(hostname)
ts=`date +%s`
curl -X POST -d "[{\"metric\": \"gitlab.projects.code\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $return_code,\"counterType\": \"GAUGE\"}]" http://127.0.0.1:1989/v1/push
