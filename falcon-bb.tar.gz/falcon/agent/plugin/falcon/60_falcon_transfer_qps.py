#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/11/14 17:54
# @Author  : Bob Zou
# @Mail    : bob_zou@trendmicro.com
# @File    : 60_falcon_qps.py
# @Software: PyCharm
# @Function:

import urllib2
import json
import os
import datetime
import pytz

def do_request(url, method, data=None, headers=None):
    if not headers:
        headers = {}

    headers.update({'content-type': 'application/json'})

    if data:
        request = urllib2.Request(url=url, data=json.dumps(data), headers=headers)
        request.get_method = lambda: method
    else:
        request = urllib2.Request(url=url, headers=headers)
        request.get_method = lambda: method

    response = urllib2.urlopen(request)

    return response


def format_original_data(data):
    timestamp = (datetime.datetime.strptime(data['Time'], "%Y-%m-%d %H:%M:%S").replace(tzinfo=pytz.timezone('Asia/Shanghai')) - datetime.datetime(1970, 1, 1, tzinfo=pytz.utc)).total_seconds()
    if data.has_key('Qps'):
        if data['Name'] == "SendToJudgeCnt":
            return [
                {
                    "endpoint": endpointName,
                    "metric": "sendto.judge.cnt.qps",
                    "value": data['Qps'],
                    "counterType": "GAUGE",
                    "step": 60,
                    "timestamp": int(timestamp),
                    "tags": "module=transfer"
                },
            ]
        elif data['Name'] == "SendToTsdbCnt":
            return [
                {
                    "endpoint": endpointName,
                    "metric": "sendto.tsdb.cnt.qps",
                    "value": data['Qps'],
                    "counterType": "GAUGE",
                    "step": 60,
                    "timestamp": int(timestamp),
                    "tags": "module=transfer"
                },
            ]
        elif data['Name'] == "SendToKafkaCnt":
            return [
                {
                    "endpoint": endpointName,
                    "metric": "sendto.kafka.cnt.qps",
                    "value": data['Qps'],
                    "counterType": "GAUGE",
                    "step": 60,
                    "timestamp": int(timestamp),
                    "tags": "module=transfer"
                },
            ]
        elif data['Name'] == "SendToGraphCnt":
            return [
                {
                    "endpoint": endpointName,
                    "metric": "sendto.graph.cnt.qps",
                    "value": data['Qps'],
                    "counterType": "GAUGE",
                    "step": 60,
                    "timestamp": int(timestamp),
                    "tags": "module=transfer"
                },
            ]
        else:
            return []
    else:
        return []


def main():
    response = do_request("http://127.0.0.1:6060/counter/all", "GET")
    # response = do_request("http://192.168.198.178:6060/counter/all", "GET")
    response = json.loads(response.read())
    if response.has_key('msg') and response['msg'] == 'success':
        for data in response['data']:
            formated_data = format_original_data(data)
            jsonData.extend(formated_data)

    print json.dumps(jsonData)


if __name__ == '__main__':
    jsonData = []
    endpointName = os.uname()[1]
    main()