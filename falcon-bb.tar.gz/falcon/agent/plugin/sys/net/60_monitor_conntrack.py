#! /usr/bin/env python2
#-*- coding:utf-8 -*-
# author:qifenggang
# monitor conntrack used

import os,sys
import time,datetime,json


nf_conntrack_count=os.popen("cat /proc/sys/net/netfilter/nf_conntrack_count").read()
nf_conntrack_max=os.popen("cat /proc/sys/net/nf_conntrack_max").read()
try:
    nf_conntrack_used_percent=float(nf_conntrack_count)/float(nf_conntrack_max)
except Exception as e :
    sys.exit(0)


data = [{
        'metric': 'nf_conntrack.used.count',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': float(nf_conntrack_count),
        'counterType': 'GAUGE',
        'tags': ''
    },
    {
        'metric': 'nf_conntrack.max.count',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': float(nf_conntrack_max),
        'counterType': 'GAUGE',
        'tags': ''
    },
    {
        'metric': 'nf_conntrack.max.percent',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': nf_conntrack_used_percent,
        'counterType': 'GAUGE',
        'tags': ''
    },
]

print(json.dumps(data))

