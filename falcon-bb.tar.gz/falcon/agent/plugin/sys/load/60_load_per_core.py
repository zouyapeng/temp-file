#! /usr/bin/env python2
#-*- coding:utf-8 -*-
# author:qifenggang
# monitor conntrack used

import datetime
import json
import os
import sys
import time

cpuinfo=os.popen("cat /proc/cpuinfo").read()
loadavg=os.popen("cat /proc/loadavg").read()

cpu_count=cpuinfo.count('processor')
load1min=loadavg.split()[0]
load5min=loadavg.split()[2]
load15min=loadavg.split()[2]


data = [{
        'metric': 'load.percpu.1min',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': float(load1min)/cpu_count,
        'counterType': 'GAUGE',
        'tags': ''
    },
    {
        'metric': 'load.percpu.5min',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': float(load5min)/cpu_count,
        'counterType': 'GAUGE',
        'tags': ''
    },
    {
        'metric': 'load.percpu.15min',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': float(load15min)/cpu_count,
        'counterType': 'GAUGE',
        'tags': ''
    },
    {
        'metric': 'cpu.count',
        'endpoint': os.uname()[1],
        'timestamp': int(time.time()),
        'step': 60,
        'value': cpu_count,
        'counterType': 'GAUGE',
        'tags': ''
    },
]

print(json.dumps(data))
