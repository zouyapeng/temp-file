#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.12.60:9876;10.111.12.61:9876'
endpoint=$(hostname)
ts=$(date +%s)
sh $MQPATH/mqadmin2 ClusterList -n "$namesrv" | grep -v '#Cluster Name'|awk '{if($3==0)$2=$2"-master"; else if($3==1)$2=$2"-slave"}{print $1,$2,$4,$6,$7}' | sed 's/([0-9]\+,[0-9]\+ms)//g'|while read line
do
array=($line)
clustername=${array[0]}
broker_role=${array[1]}
ipaddr=${array[2]}
ipaddr=$(echo $ipaddr|sed 's/:/_/g')
intps=${array[3]}
outtps=${array[4]}
echo "$clustername|$broker_role|$ipaddr|$intps|$outtps"
curl -s -X POST -d "[{\"metric\": \"rocketmq-cargo.broker-intps\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $intps,\"counterType\": \"GAUGE\",\"tags\": \"cluster=$clustername,broker=$broker_role,ipaddr=$ipaddr\"},{\"metric\": \"rocketmq-cargo.broker-outtps\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $outtps,\"counterType\": \"GAUGE\",\"tags\": \"cluster=$clustername,broker=$broker_role,ipaddr=$ipaddr\"}]" http://127.0.0.1:1989/v1/push > /dev/null
done
