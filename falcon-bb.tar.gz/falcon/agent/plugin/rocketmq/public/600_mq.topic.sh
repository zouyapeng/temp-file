#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.61.170:9876;10.111.61.171:9876'
endpoint=$(hostname)
timeout 1 sh ${MQPATH}/mqadmin topicList -n "$namesrv" > public_topic_list
value=$(cat public_topic_list | wc -l)
ts=`date +%s`
cat public_topic_list|sed 's/^%//g'|sed 's/%/-/g' | while read line
do
echo $line
curl -s -X POST -d "[{\"metric\": \"rocketmq-public.topic\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": \"$value\",\"counterType\": \"GAUGE\",\"tags\": \"topic=$line\"}]" http://127.0.0.1:1989/v1/push # >/dev/null
done
