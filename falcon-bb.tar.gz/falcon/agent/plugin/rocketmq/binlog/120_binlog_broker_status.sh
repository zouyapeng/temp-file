#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.10.230:9876;10.111.10.231:9876'
endpoint=$(hostname)
ts=$(date +%s)
sh $MQPATH/mqadmin2 ClusterList -n "$namesrv" | grep -v '#Cluster Name'|awk '{if($3==0)$2=$2"-master"; else if($3==1)$2=$2"-slave"}{print $1,$2,$4,$6,$7}'> brokerstatus.log
clustername=`cat brokerstatus.log | awk '{print$1}' | sort -u `
echo $clustername
mcount=`grep 'master' brokerstatus.log | wc -l `
scount=`grep 'slave' brokerstatus.log | wc -l `
#echo $mcount
#echo $scount
curl -s -X POST -d "[{\"metric\": \"rocketmq-binlog.mcount\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 120,\"value\": $mcount,\"counterType\": \"GAUGE\",\"tags\": \"cluster=rocketmq-binlog\"},{\"metric\": \"rocketmq-binlog.scount\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 120,\"value\": $scount,\"counterType\": \"GAUGE\",\"tags\": \"cluster=rocketmq-binlog\"}]" http://127.0.0.1:1989/v1/push > /dev/null