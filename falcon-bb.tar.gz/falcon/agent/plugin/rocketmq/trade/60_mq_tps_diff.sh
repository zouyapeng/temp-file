#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.12.36:9876;10.111.12.37:9876'
endpoint=$(hostname)
timeout 1 sh ${MQPATH}/mqadmin statsAll -n "$namesrv" > trade_statsall
ts=`date +%s`
cat trade_statsall | grep -Po '[a-zA-Z_-]+\s+[a-zA-Z_-]+\s+\d+\s+\d+\.\d+\s+\d+\.\d+' | sort -k 1 -nr | while read line
do
array=($line)
topic=${array[0]}
groupname=${array[1]}
diff=${array[2]}
intps=${array[3]}
outtps=${array[4]}
#echo "$topic|$groupname|$diff|$intps|$outtps"
curl -s -X POST -d "[{\"metric\": \"rocketmq-trade.intps\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $intps,\"counterType\": \"GAUGE\",\"tags\": \"topic=$topic,groupname=$groupname\"}]" http://127.0.0.1:1989/v1/push > /dev/null
curl -s -X POST -d "[{\"metric\": \"rocketmq-trade.outtps\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $outtps,\"counterType\": \"GAUGE\",\"tags\": \"topic=$topic,groupname=$groupname\"}]" http://127.0.0.1:1989/v1/push > /dev/null
curl -s -X POST -d "[{\"metric\": \"rocketmq-trade.accumulation\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $diff,\"counterType\": \"GAUGE\",\"tags\": \"topic=$topic,groupname=$groupname\"}]" http://127.0.0.1:1989/v1/push > /dev/null
done
