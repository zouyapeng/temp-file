#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.61.170:9876;10.111.61.171:9876'
endpoint=$(hostname)
ts=$(date +%s)
timeout 5s sh $MQPATH/mqadmin ClusterList -n "$namesrv" | grep -v '#Cluster Name'|awk '{if($3==0)$2=$2"-master"; else if($3==1)$2=$2"-slave"}{print $1,$2,$4,$6,$7}'> rocketmq-public-status.log
clustername=`cat rocketmq-public-status.log | awk '{print$1}' | sort -u `
#echo $clustername
mcount=`grep 'master' rocketmq-public-status.log | wc -l `
scount=`grep 'slave' rocketmq-public-status.log | wc -l `
#echo $mcount
#echo $scount
curl -s -X POST -d "[{\"metric\": \"rocketmq-public.mcount\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $mcount,\"counterType\": \"GAUGE\",\"tags\": \"cluster=$clustername\"},{\"metric\": \"rocketmq-public.scount\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 60,\"value\": $scount,\"counterType\": \"GAUGE\",\"tags\": \"cluster=$clustername\"}]" http://127.0.0.1:1989/v1/push > /dev/null