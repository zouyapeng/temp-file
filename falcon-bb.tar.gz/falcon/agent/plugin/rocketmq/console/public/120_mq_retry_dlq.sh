#!/bin/bash
MQPATH='/data/rocketmq/bin'
namesrv='10.111.61.170:9876;10.111.61.171:9876'
endpoint=$(hostname)
ts=$(date +%s)
echo "`timeout --signal=2 2s sh ${MQPATH}/mqadmin topicList -n $namesrv | egrep '%RETRY%|%DLQ%'`"| while read line
do
#timeout 1 sh ${MQPATH}/mqadmin topicStatus -n $namesrv -t "$line"|grep -v '^#Broker Name' |sed "s/^/$line\\t/g" |awk 'BEGIN{OFS="|"}{print $1,$2,$5}' >>output
timeout 3 sh ${MQPATH}/mqadmin topicStatus -n $namesrv -t "$line"|grep -v '^#Broker Name' |awk -v topic="$line" 'BEGIN{OFS="|"}{print topic,$1,$4}' >>rocketmq-public-output
done
cat rocketmq-public-output |while read mq_retry_dlq
do
OLD_IFS="$IFS"
IFS="|"
array=(${mq_retry_dlq})
topic=${array[0]}
topic=$(echo "$topic"|sed 's/^%//g'|sed 's/%/-/g')
broker=${array[1]}
offset=${array[2]}
#echo "$topic|$broker|$offset"
if [[ "$topic" =~ "RETRY" ]];then
curl -s -X POST -d "[{\"metric\": \"rocketmq-public.retry-offset\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 120,\"value\": $offset,\"counterType\": \"GAUGE\",\"tags\": \"topic=$topic,broker=$broker\"}]" http://127.0.0.1:1989/v1/push >/dev/null
else
curl -s -X POST -d "[{\"metric\": \"rocketmq-public.dlq-offset\", \"endpoint\": \"$endpoint\", \"timestamp\": $ts,\"step\": 120,\"value\": $offset,\"counterType\": \"GAUGE\",\"tags\": \"topic=$topic,broker=$broker\"}]" http://127.0.0.1:1989/v1/push >/dev/null
fi
done
if [ -f rocketmq-public-output ];then
>rocketmq-public-output
fi